import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const projectUrl = Deno.env.get("SUPABASE_URL");
  const apiKey = request.headers.get("apikey") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY");
  const authorization = request.headers.get("Authorization");
  if (!projectUrl || !apiKey || !authorization?.startsWith("Bearer ")) {
    return json({ error: "Missing Supabase configuration or user session." }, 401);
  }

  const supabase = createClient(projectUrl, apiKey, {
    auth: { autoRefreshToken: false, persistSession: false },
    global: { headers: { Authorization: authorization } },
  });
  const accessToken = authorization.slice("Bearer ".length);
  const { data: authData, error: authError } = await supabase.auth.getUser(accessToken);
  if (authError || !authData.user) {
    return json({ error: "Invalid user session." }, 401);
  }

  const action = new URL(request.url).searchParams.get("action");
  if (action === "load" && request.method === "GET") {
    const { data, error } = await supabase
      .from("game_saves")
      .select("slot,state,deleted,updated_at")
      .order("slot", { ascending: true });
    if (error) return json({ error: error.message }, 500);

    const slots: Record<string, unknown>[] = Array.from({ length: 3 }, () => ({}));
    for (const row of data ?? []) {
      slots[row.slot] = row.deleted
        ? { _deleted: true, updated_at: Math.floor(new Date(row.updated_at).getTime() / 1000) }
        : row.state as Record<string, unknown>;
    }
    return json(slots);
  }

  if (request.method !== "POST" || !["save", "delete"].includes(action ?? "")) {
    return json({ error: "Unsupported action." }, 404);
  }

  let body: { slot?: unknown; state?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: "Invalid JSON body." }, 400);
  }

  const slot = Number(body.slot);
  if (!Number.isInteger(slot) || slot < 0 || slot > 2) {
    return json({ error: "Slot must be an integer from 0 to 2." }, 400);
  }

  if (action === "delete") {
    const { error } = await supabase
      .from("game_saves")
      .upsert({
        user_id: authData.user.id,
        slot,
        state: {},
        deleted: true,
        updated_at: new Date().toISOString(),
      });
    if (error) return json({ error: error.message }, 500);
    return json({ ok: true });
  }

  if (!body.state || typeof body.state !== "object" || Array.isArray(body.state)) {
    return json({ error: "State must be a JSON object." }, 400);
  }
  const { error } = await supabase.from("game_saves").upsert({
    user_id: authData.user.id,
    slot,
    state: body.state,
    deleted: false,
    updated_at: new Date().toISOString(),
  });
  if (error) return json({ error: error.message }, 500);
  return json({ ok: true });
});
