# Guardados remotos de Granja Sin Base

El juego conserva sus guardados locales y, cuando se configura Supabase, sincroniza las tres ranuras con PostgreSQL a través de la función `game-saves`.

## Preparar Supabase

1. Crea un proyecto de Supabase y activa **Authentication → Sign In / Providers → Anonymous Sign-Ins**.
2. En el SQL Editor del proyecto, ejecuta `migrations/20261016000000_game_saves.sql`.
3. Instala e inicia sesión con Supabase CLI, enlaza este directorio al proyecto y despliega la función:

   ```powershell
   supabase login
   supabase link --project-ref TU_PROJECT_REF
   supabase functions deploy game-saves
   ```

   La función mantiene la verificación JWT activada. La política RLS restringe cada ranura al usuario autenticado que la creó.

4. En `scripts/global.gd`, configura estas tres constantes con los datos de **Project URL** y **Publishable key** del panel de Supabase:

   ```gdscript
   const SUPABASE_URL := "https://TU_PROJECT_REF.supabase.co"
   const SUPABASE_PUBLISHABLE_KEY := "sb_publishable_..."
   const DATABASE_ENDPOINT := "https://TU_PROJECT_REF.supabase.co/functions/v1/game-saves"
   ```

   La clave publishable está diseñada para estar en el cliente. Nunca pongas la clave `sb_secret_...` ni una clave `service_role` en el juego.

## Qué sincroniza

- `GET ?action=load`: devuelve una lista de tres ranuras, usando `{}` para las vacías.
- `POST ?action=save`: recibe `{ "slot": 0, "state": { ... } }` y guarda el estado como JSONB.
- `POST ?action=delete`: recibe `{ "slot": 0 }` y registra una eliminación remota para que también se refleje en otros dispositivos.

El juego crea una sesión anónima de Supabase y guarda localmente el token de renovación. Para poder recuperar las partidas en otro dispositivo, posteriormente habría que vincular esa sesión anónima a una cuenta permanente.
