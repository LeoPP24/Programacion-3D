extends Control
## Mochila con celdas preparadas para conectar sprites propios desde el Inspector.

@export_group("Assets de productos animales")
@export var icono_leche: Texture2D
@export var icono_huevo: Texture2D

var _celdas: Array[Dictionary] = []
var _tiempo_actualizacion := 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	_crear_interfaz()
	actualizar_contenido()


func _process(delta: float) -> void:
	if not visible:
		return
	_tiempo_actualizacion += delta
	if _tiempo_actualizacion >= 0.25:
		_tiempo_actualizacion = 0.0
		actualizar_contenido()


func actualizar_contenido() -> void:
	if _celdas.is_empty():
		return
	var productos: Array[Dictionary] = []
	for indice in Global.CROPS.size():
		productos.append({
			"id": str(Global.CROPS[indice].id),
			"nombre": str(Global.CROPS[indice].name),
			"icono": Global.icono_cultivo(indice),
		})
	productos.append({"id": "leche", "nombre": "Leche", "icono": icono_leche})
	productos.append({"id": "huevo", "nombre": "Huevo", "icono": icono_huevo})
	for indice in _celdas.size():
		var celda: Dictionary = _celdas[indice]
		var tiene_producto := indice < productos.size()
		celda.nombre.visible = true
		if tiene_producto:
			var producto: Dictionary = productos[indice]
			celda.nombre.text = str(producto.nombre)
			celda.cantidad.text = "× %d" % int(Global.inventory.get(producto.id, 0))
			celda.icono.texture = producto.icono
			celda.placeholder.visible = producto.icono == null
		else:
			celda.nombre.text = "Espacio para asset"
			celda.cantidad.text = ""
			celda.icono.texture = null
			celda.placeholder.visible = true


func _crear_interfaz() -> void:
	var fondo := ColorRect.new()
	fondo.name = "FondoOscuro"
	fondo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fondo.color = Color(0.04, 0.06, 0.08, 0.72)
	fondo.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(fondo)
	var panel := PanelContainer.new()
	panel.name = "PanelMochila"
	panel.position = Vector2(250, 86)
	panel.size = Vector2(700, 548)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(panel)
	var columna := VBoxContainer.new()
	columna.add_theme_constant_override("separation", 14)
	panel.add_child(columna)
	var encabezado := HBoxContainer.new()
	columna.add_child(encabezado)
	var titulo := Label.new()
	titulo.text = "MOCHILA"
	titulo.add_theme_font_size_override("font_size", 28)
	titulo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	encabezado.add_child(titulo)
	var cerrar := Button.new()
	cerrar.text = "CERRAR [B]"
	cerrar.focus_mode = Control.FOCUS_NONE
	cerrar.pressed.connect(_cerrar)
	encabezado.add_child(cerrar)
	var ayuda := Label.new()
	ayuda.text = "Cosechas y productos del corral · Esc o B para cerrar"
	columna.add_child(ayuda)
	var cuadricula := GridContainer.new()
	cuadricula.name = "CeldasInventario"
	cuadricula.columns = 2
	cuadricula.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cuadricula.add_theme_constant_override("h_separation", 10)
	cuadricula.add_theme_constant_override("v_separation", 10)
	columna.add_child(cuadricula)
	# Hay cinco cultivos y dos productos animales en la lista de arriba.
	for indice in 7:
		var celda_panel := PanelContainer.new()
		celda_panel.name = "EspacioProducto%02d" % indice
		celda_panel.custom_minimum_size = Vector2(300, 105)
		cuadricula.add_child(celda_panel)
		var fila := HBoxContainer.new()
		fila.add_theme_constant_override("separation", 8)
		celda_panel.add_child(fila)
		var zona_icono := Control.new()
		zona_icono.name = "IconSlot"
		zona_icono.custom_minimum_size = Vector2(58, 58)
		fila.add_child(zona_icono)
		var icono := TextureRect.new()
		icono.name = "IconoProducto"
		icono.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		icono.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icono.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icono.mouse_filter = Control.MOUSE_FILTER_IGNORE
		zona_icono.add_child(icono)
		var placeholder := Label.new()
		placeholder.name = "PuntoParaAsset"
		placeholder.text = "ASSET"
		placeholder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		placeholder.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		placeholder.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		placeholder.add_theme_font_size_override("font_size", 10)
		placeholder.add_theme_color_override("font_color", Color(0.7, 0.72, 0.74, 0.65))
		placeholder.mouse_filter = Control.MOUSE_FILTER_IGNORE
		zona_icono.add_child(placeholder)
		var texto := VBoxContainer.new()
		texto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		texto.add_theme_constant_override("separation", 4)
		fila.add_child(texto)
		var nombre := Label.new()
		nombre.name = "NombreProducto"
		nombre.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		nombre.add_theme_font_size_override("font_size", 13)
		texto.add_child(nombre)
		var cantidad := Label.new()
		cantidad.name = "CantidadProducto"
		cantidad.add_theme_font_size_override("font_size", 18)
		texto.add_child(cantidad)
		_celdas.append({"icono": icono, "placeholder": placeholder, "nombre": nombre, "cantidad": cantidad})


func _cerrar() -> void:
	visible = false
	var juego := get_parent().get_parent()
	juego.call("cerrar_mochila")
