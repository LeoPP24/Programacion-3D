extends Node2D
## Parcela vecinal: muestra el terreno y, al terminar la construcción, la casa y su residente.

@export_group("Assets editables")
@export var textura_casa: Texture2D = preload("res://Sprout Lands - Sprites - Basic pack/Objects/Free_Chicken_House.png")
@export var textura_vecina: Texture2D = preload("res://Sprout Lands - Sprites - Basic pack/Characters/Basic Charakter Spritesheet.png")
@export var textura_terreno: Texture2D
@export var tamano_terreno := Vector2(96, 96)


func _ready() -> void:
	_actualizar_terreno()


func _actualizar_terreno() -> void:
	var suelo := get_node_or_null("Suelo") as Polygon2D
	if suelo == null:
		return
	var mitad := tamano_terreno * 0.5
	suelo.polygon = PackedVector2Array([
		Vector2(-mitad.x, -mitad.y), Vector2(mitad.x, -mitad.y),
		Vector2(mitad.x, mitad.y), Vector2(-mitad.x, mitad.y),
	])
	suelo.color = Color.WHITE if textura_terreno != null else Color("#9a6842")
	suelo.texture = textura_terreno


func crear_casa(nombre_vecina: String) -> void:
	if has_node("CasaVecina"):
		return
	var casa := Node2D.new()
	casa.name = "CasaVecina"
	casa.position = Vector2(0, -38)
	var textura := Sprite2D.new()
	textura.texture = textura_casa
	textura.scale = Vector2(2.0, 2.0)
	casa.add_child(textura)
	var vecina := Sprite2D.new()
	vecina.texture = textura_vecina
	vecina.hframes = 4
	vecina.vframes = 4
	vecina.frame = 15
	vecina.scale = Vector2(2.0, 2.0)
	vecina.position = Vector2(40, 62)
	casa.add_child(vecina)
	var cuerpo_colision := StaticBody2D.new()
	cuerpo_colision.name = "ColisionEstructura"
	var volumen := CollisionShape2D.new()
	volumen.name = "VolumenCompleto"
	var forma := RectangleShape2D.new()
	forma.size = Vector2(112, 88)
	volumen.shape = forma
	volumen.position = Vector2(0, -4)
	cuerpo_colision.add_child(volumen)
	casa.add_child(cuerpo_colision)
	var etiqueta := Label.new()
	etiqueta.text = nombre_vecina
	etiqueta.position = Vector2(-42, 42)
	etiqueta.add_theme_font_size_override("font_size", 16)
	casa.add_child(etiqueta)
	add_child(casa)
