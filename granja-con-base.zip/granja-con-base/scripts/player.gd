extends CharacterBody2D

@export var speed := 260.0
@export var limites := Rect2(-180, -120, 3940, 1680)
@export var margen := 26.0
@export var fps := 8.0           # velocidad de la animación
@export var fila_abajo := 0      # fila de la hoja para cada dirección
@export var fila_arriba := 1
@export var fila_izquierda := 2
@export var fila_derecha := 3

@onready var sprite: Sprite2D = %Sprite

var fila := 0
var tiempo := 0.0


func _physics_process(delta: float) -> void:
	var dir := Input.get_vector("mover_izq", "mover_der", "mover_arr", "mover_aba")
	velocity = dir * speed
	var paso := velocity * delta
	if not is_zero_approx(dir.x) and not is_zero_approx(dir.y):
		paso *= 0.70710678
	var posicion_anterior := global_position
	if not is_zero_approx(paso.x):
		move_and_collide(Vector2(paso.x, 0.0))
		if not _posicion_valida():
			global_position = posicion_anterior
			velocity.x = 0.0
	var antes_de_mover_y := global_position
	if not is_zero_approx(paso.y):
		move_and_collide(Vector2(0.0, paso.y))
		if not _posicion_valida():
			global_position = antes_de_mover_y
			velocity.y = 0.0
	position = position.clamp(limites.position + Vector2(margen, margen), limites.end - Vector2(margen, margen))

	var cuadro := 0
	if dir != Vector2.ZERO:
		if absf(dir.x) > absf(dir.y):
			fila = fila_derecha if dir.x > 0.0 else fila_izquierda
		else:
			fila = fila_abajo if dir.y > 0.0 else fila_arriba
		tiempo += delta * fps
		cuadro = int(tiempo) % sprite.hframes
	else:
		tiempo = 0.0
	sprite.frame = fila * sprite.hframes + cuadro


func _posicion_valida() -> bool:
	var mapa := get_parent()
	if mapa.has_method("can_stand_at"):
		return mapa.can_stand_at(global_position, 14.0)
	if mapa.has_method("is_on_land"):
		return mapa.is_on_land(global_position)
	return true
