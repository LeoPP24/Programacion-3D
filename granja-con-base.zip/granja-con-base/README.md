# Granja (Godot 4)

Abre `project.godot` con Godot 4.x y presiona F5.

Controles: WASD / flechas = mover, E o Espacio = interactuar, 1-8 = elegir semilla, Esc = volver al menú.

## Escenas (todo son nodos editables)
- `scenes/menu.tscn`: Fondo, título, botones Jugar / Configuración / Salir y el slider de volumen.
- `scenes/game.tscn`: Mapa, Mercado, Vaca, Parcelas (18 instancias de plot.tscn), Jugador y HUD (barra de XP, monedas, panel de precios, mensajes, barra de semillas).
- `scenes/plot.tscn`: una parcela (Suelo, Planta, Barra de crecimiento, Resalte).
- `scenes/player.tscn`: el personaje (Cuerpo y Cabeza).

Para poner sprites: reemplaza o agrega un Sprite2D dentro de Jugador, Vaca, Mercado o Parcela (plot.tscn). Para más parcelas, duplica una instancia dentro de `Parcelas`.
Los valores de balance (tiempo de crecimiento, intervalo de precios, vaca, cultivos y XP) están al inicio de `scripts/global.gd`.

## Nuevas funciones
- El rancho inicial ahora está en una isla irregular rodeada por agua; la cámara sigue al jugador y hay una isla secundaria conectada por un puente.
- Los tres terrenos vecinos están a la venta. Después de comprar el terreno puedes encargar una casa; tarda 5 minutos y aparece una alerta cuando queda lista.
- Rosa, Edith y Rubí ofrecen encargos de cosechas o productos animales. Algunas recompensas son dinero y otras muebles.
- Las vacas y gallinas permanecen dentro del corral junto a la casa. Producen leche y huevos que se pueden recoger y vender en la tienda.
- La tienda queda al costado del rancho.
- El menú ofrece tres espacios de partida. En un espacio vacío pide el nombre del nuevo granjero; las partidas se guardan localmente en `user://partidas.json` y se actualizan automáticamente.

## PostgreSQL (sincronización opcional)
El juego funciona sin servidor y guarda tres espacios localmente. Para sincronizarlos entre instalaciones:
1. Crea una base PostgreSQL y ejecuta `database/schema.sql`.
2. Publica `database/save.php` en un servidor PHP con PDO_PGSQL habilitado, solo por HTTPS. Configura `GRANJA_PG_DSN`, `GRANJA_PG_USER` y `GRANJA_PG_PASSWORD` como variables privadas del servidor.
3. En `scripts/global.gd`, asigna `DATABASE_ENDPOINT` a la URL HTTPS del archivo `save.php` (sin parámetros).

El juego envía y recupera los tres espacios mediante ese API. Las credenciales de PostgreSQL permanecen en el servidor. Sin la URL configurada, se usan únicamente las partidas locales.
